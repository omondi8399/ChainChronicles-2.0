<?php
include('session.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title> Welcome | Jersey Yetu House </title>
</head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a href="products.php">BACK</a>
    <a><?php echo $login_session; ?></a>
</header>
    <hr>
<?php
include('db2.php');

$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="jezi";
$conn=new mysqli($host, $dbUsername, $dbPassword, $dbName);
if($conn -> connect_error){
    die("connection failed:".$conn->connect_error);
}?> 

<?php
$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query(
$con,
"SELECT * FROM `products` WHERE `code`='$code'"
);
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$code = $row['code'];
$price = $row['price'];
$image = $row['image'];

$cartArray = array(
	$code=>array(
	'name'=>$name,
	'code'=>$code,
	'price'=>$price,
	'quantity'=>1,
	'image'=>$image)
);

if(empty($_SESSION["shopping_cart"])) {
    $_SESSION["shopping_cart"] = $cartArray;
    $status = "<div class='box'>Product is added to your cart!</div>";
}else{
    $array_keys = array_keys($_SESSION["shopping_cart"]);
    if(in_array($code,$array_keys)) {
	$status = "<div class='box' style='color:red;'>
	Product is already added to your cart!</div>";	
    } else {
    $_SESSION["shopping_cart"] = array_merge(
    $_SESSION["shopping_cart"],
    $cartArray
    );
    $status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}
?>
<body>
<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="cart_div">
<a href="cart.php"><img src="img/arsenal.png" widht="30px" height="30px"/> Cart<span>
<?php echo $cart_count; ?></span></a>
</div>
<?php
}
?>
<h2>Select product</h2>
<form action="" method="POST">
<?php      
$result = $conn->query("SELECT DISTINCT type from products");
echo "<select name='type'>";
while ($row = $result->fetch_assoc()){
    unset($mplate,$mtype);
    $mplate = $row['type'];
    $mtype = $row['type'];
    echo '<option value="'.$mplate.'">'.$mplate.'</option>';
}
echo "</select></br></br>";?>
<input type="submit" name="submit-search" value="Search">
</form>

<?php
if(isset($_POST['submit-search'])){
    $type=$_POST['type']; 
    echo "<h1>".$type."</h1>";
    $sql = "SELECT * FROM products WHERE
    type='$type'";
    $result = mysqli_query($conn,$sql);
    $queryResult = mysqli_num_rows($result);
   ?>
   <?php
 if($queryResult > 0){
        while ($row = mysqli_fetch_assoc($result)){        
       ?>
       
<?php
$result = mysqli_query($con,"SELECT * FROM `products` where type='$type'");
while($row = mysqli_fetch_assoc($result)){
    echo "<div class='product_wrapper'>
    <form method='post' action=''>
    <input type='hidden' name='code' value=".$row['code']." />
    <div class='image'><img src='".$row['image']."' /></div>
    <div class='name'>".$row['name']."</div>
	<div class='name'>".$row['type']."</div>
	<div class='name'>".$row['size']."</div>
    <div class='price'>Ksh ".$row['price']."</div>
    <button type='submit' class='buy'>Buy Now</button>
    </form>
    </div>";
        }
mysqli_close($con);
?><?php
 }
    }
}else{
   
}   
?>
<div style="clear:both;"></div>
<div class="message_box" style="margin:10px 0px;">
<?php echo $status; ?>
</div>
</body>
<footer>
<p>JERSEY YETU HOUSE</p>
<p>Copyright 2020-2021</p>
</footer>
</body>
</html>