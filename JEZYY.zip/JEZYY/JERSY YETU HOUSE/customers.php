<?php

?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>

</header>
    <hr>
<h1>ALL CUSTOMERS </h1>
<section>
<a href="customers.php">VIEW CUSTOMERS</a>
</section>
<section>
<a href="transactions.php">TRANSACTIONS</a>
</section> <section>
<a href="addemployee.php">ADD EMPLOYEE</a>
</section> <section>
<a href="addproducts.php">ADD PRODUCTS</a>
</section>
<div class="all_members">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM customers Order by registration_date desc";     
            $records = mysqli_query($con,$sql);?>
            <table>
              
                <thead>
                <tr>
                <th>Username</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Address</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['username'].'</td>';
                echo '<td>'.$row['name'].'</td>';
                echo '<td>'.$row['phone_number'].'</td>';
                echo '<td>'.$row['email'].'</td>';
                echo '<td>'.$row['address'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>    
                    </table>                      
                </div>
               
                </body>
                </html>