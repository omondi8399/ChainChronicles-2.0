<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Finance and Management </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
    <h1>PRICE REGULATION</h1>
    <section>
<a href="productsprices.php">PRICE REGULATION</a>
</section>
    <section>
<a href="finance.php">VIEW ORDERS</a>
</section>
<section>
<a href="customers.php">CUSTOMERS</a>
</section>
<section>
<a href="transactions.php">TRANSACTIONS</a>
</section>  <section>
<a href="reports.php">REPORTS</a>
</section>

<div class="all_members">
<?php
include('db2.php');
                $result = mysqli_query($con,"SELECT * FROM `products`");
                while($row = mysqli_fetch_assoc($result)){
                    echo "<div class='product_wrapper'>
                    <form method='post' action=''>
                    <input type='hidden' name='code' value=".$row['code']." />
                    <div class='image'><img src='".$row['image']."' /></div>
                    <div class='name'>".$row['name']."</div>
                    <div class='type'>".$row['type']."</div>
                    <div class='size'>".$row['size']."</div>
                    <div class='price'>Ksh ".$row['price']."</div>
                    <button type='submit' class='buy'>Change</button>
                    </form>
                    </div>";
                        }
                mysqli_close($con);
                ?>

</div>
</body>
</html>