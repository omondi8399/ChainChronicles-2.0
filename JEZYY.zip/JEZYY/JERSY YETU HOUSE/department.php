<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Human resource </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>DEPARTMENTS</h1>
<section>
<a href="department.php">DEPARTMENTS</a>
</section>
<section>
<a href="hr.php">VIEW EMPLOYEES</a>
</section>
 <section>
<a href="addemployee.php">RECRUIT EMPLOYEE</a>
</section>
<div class="all_members">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM department";     
            $records = mysqli_query($con,$sql);?>
            <table>
                <thead>
                <tr>
                <th>Department id</th>
                <th>Department Name</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['department_id'].'</td>';
                echo '<td>'.$row['name'].'</td>';
                echo "</tr>";
                echo "</tbody>";
                    }?>  
                    </table>               
                </div>
                <h1>ADD NEW DEPARTMENT</h1>
                <form name="" action="adddepartment.php" method="POST">
                <h3>Name <input type="text" name="depname" required></h3>
                <h3>Department Id <input type="text" name="id" required></h3>
                <h3> <input type="submit" value="SUBMIT"></h3>
                </form>
</div>
</body>
</html>