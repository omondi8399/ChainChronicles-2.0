<?php
include('session.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title> Transactions | Jersey Yetu House </title>
</head>
<body>
    <header>
    <a href="logout.php">LOG OUT </a>
    <a href="products.php">BACK |</a>
	<a style="text-transform:capitalize"><?php echo $login_session; ?> |</a>
</header>
    <hr>
    <h1>PENDING TRANSACTIONS</h1>

    <?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM cust_transacts where transact_by='$login_session' order by date desc";     
            $records = mysqli_query($con,$sql);?>
            <table>
              
                <thead>
                <tr>
                <th>Trans Id.</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Date and Time</th>
                <th>Delivered</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['t_id'].'</td>';
                echo '<td>'.$row['product'].'</td>';
                echo '<td>'.$row['quantity'].'</td>';
                echo '<td> Ksh'.$row['price'].'</td>';
                echo '<td>'.$row['date'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>    
                    </table>                      
                </div>
       
<h1>OLD TRANSACTIONS</h1>
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM cust_transacts where transact_by='$login_session' order by date desc";     
            $records = mysqli_query($con,$sql);?>
            <table>
              
                <thead>
                <tr>
                <th>Trans Id.</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Date and Time</th>
                <th>Delivered</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['t_id'].'</td>';
                echo '<td>'.$row['product'].'</td>';
                echo '<td>'.$row['quantity'].'</td>';
                echo '<td> Ksh'.$row['price'].'</td>';
                echo '<td>'.$row['date'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>    
                    </table>                      
                </div>
               

</body>
<footer>
<p>JERSEY YETU HOUSE</p>
<p>Copyright 2020-2021</p>
</footer>
</body>
</html>