<?php
   session_start();
   $host="localhost";
   $dbUsername="root";
   $dbPassword="";
   $dbName="jezi";
   $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);
   if($con)
   $name=$_POST['depname'];
   $id=$_POST['id']; 
    $sql="INSERT INTO department(department_id,name,passw) VALUES('$id','$name','$name')" ;     $query=mysqli_query($con,$sql);
	   if($query){
		   header('location:department.php');
	   }
	   else
		   echo 'Try again to register with different id number. Registration not successfull';
           include('department.php');
?>