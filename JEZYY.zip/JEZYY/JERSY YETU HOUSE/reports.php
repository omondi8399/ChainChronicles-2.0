<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Finance and Management </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr><form name="" action="" method="POST">
    <h1>Choose date to generate report <input type="date" name="date" required> <input type="submit" value="Generate report"></h1>
</form>
    <section>
<a href="reports.php">REPORTS</a>
</section>
    <section>
<a href="finance.php">VIEW ORDERS</a>
</section>
<section>
<a href="customers.php">CUSTOMERS</a>
</section>
<section>
<a href="transactions.php">TRANSACTIONS</a>
</section>  
<section>
<a href="products.php">PRODUCTS</a>
</section>
<div class="all_members">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM cust_transacts order by date asc";     
            $records = mysqli_query($con,$sql);?>
            <table>
                <thead>
                <tr>
                <th>Username</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Time</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['transact_by'].'</td>';
                echo '<td>'.$row['product'].'</td>';
                echo '<td>'.$row['quantity'].'</td>';
                echo '<td>'.$row['price'].'</td>';
                echo '<td>'.$row['date'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>

</div>
<a href="">Sales</a> |
<a href="">Transactions</a> |
<a href="">Reports</a> 
</body>
</html>