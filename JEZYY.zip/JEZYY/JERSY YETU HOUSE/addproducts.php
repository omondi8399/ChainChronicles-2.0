<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Human resource </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>ADD NEW PRODUCT</h1>
<section>
<a href="addproducts.php">ADD NEW PRODUCTS</a>
</section> 
<section>
 <a href="warehouse.php">INVENTORY</a> </section>
 <section>
<a href="">REPORTS</a> 
</section>
 <div class="all_members">
<form name="" action="productdata.php" method="POST">
    <table>
        <tr>
            <td><h3>Product Name</h3></td>
            <td><h3><input type="text" name="name" required></h3></td>
       </tr>
       <tr>
            <td><h3>Product code</h3></td>
            <td><h3><input type="text" name="code" required></h3></td>
       </tr>
       <tr>
            <td><h3>Price</h3></td>
            <td><h3><input type="number" name="price" required></h3></td>
       </tr>
       <tr>
       <td> <input type="submit" value="SUBMIT"> </td>
</tr>
    </table>
    

               
                </form>
                </div>
                </body>
                </html>
