<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"></head>
<title>Welcome | Jersey Yetu House </title>
<body>
    <header>
    <a href="products.php">PRODUCTS</a>
    <a href="index.php">HOME</a>
</header>
    <hr>
<h1>SIGN UP</h1>
<div class="login-box">
<form name="newaccount" action="signup.php" METHOD="POST">
    <h3>Username <input type="text" name="username" required></h3>
    
    <h3>Name <input type="text" name="name" required></h3>
    
    <h3>Email <input type="text" name="email" required></h3>
    
    <h3>Gender
   <select name="gender">
       <option value="">Scroll down:-</option>
       <option value="M">Male</option>
       <option value="F">Female</option>
    </select></h3>
    <h3>Address <input type="text" name="address" required></h3>
    <h3>Phone number <input type="text" name="phone" required></h3>
    <h3>password <input type="password" name="pass" required></h3>
    <h3>Confirm Password <input type="password" name="passwordconf" required></h3>
    <input type="submit" value="Signup">
</form>
<footer>
<p>JERSEY YETU HOUSE</p>
<p>Copyright 2020-2021</p>
</footer>
</body>
</html>