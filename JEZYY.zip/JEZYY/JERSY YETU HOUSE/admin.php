<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>ADMINISTRATORS PANEL </h1>
<section>
<a href="finalog.php">FINANCE</a>
</section>
<section>
<a href="marketlog.php">MARKETING</a>
</section> <section>
<a href="whlog.php">WAREHOUSE</a>
</section> <section>
<a href="hrlogin.php">HUMAN RESOURCE</a>
</section>       </body>  </html>
