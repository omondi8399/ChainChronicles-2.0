<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Human Resource | Add employee | Jersey Yetu House </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>RECRUIT EMPLOYEE</h1>
<section>
<a href="addemployee.php">RECRUIT EMPLOYEE</a>
</section>
<section>
<a href="hr.php">VIEW EMPLOYEES</a>
</section>
<section>
<a href="department.php">DEPARTMENTS</a>
</section>
<div class="all_members">
    <form name="" action="employeereg.php" method="POST">
  
            <h3>Name  <input type="text" name="name" required></h3>
            <h3>Id Number <input type="text" name="idno" required></h3>
            <h3>Email <input type="email" name="email" required></h3>
            <h3>Phone Number <input type="text" name="phone" required></h3></td>
            <h3>Date of birth <input type="date" name="dob" required></h3></td>
            <h3>Gender <select name="gender" required>
                    <option value="">Scroll down:-</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select></h3>
            <h3>Department <select name="department" required>
                    <option value="">Scroll down:-</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Trasnsport">Transport</option>
                    <option value="Human Resource">Human Resource</option>
                    <option value="Communication">Communication</option>
                    <option value="Storage and Warehousing">Storage and Warehousing</option>
                    <option value="Finance and Management">Finance and Management</option>
                </select></h3>
                <h3>Department id <select name="department_id" required>
                    <option value="">Scroll down:-</option>
                    <option value="MKT92039">MKT92039</option>
                    <option value="TRS90007">TRS90007</option>
                    <option value="HR93004">TRS90007</option>
                    <option value="CMS90004">CMS90004</option>
                    <option value="STW90494">STW90494</option>
                    <option value="FMNG495">MNG495</option>
                </select></h3></td>
      </tr>
</table>
               </br></br>
                <input type="submit" value="SUBMIT">
                </form>
        </div>
    </body>
</html>