<?php
   if($_SERVER["REQUEST_METHOD"] == "POST") { 
    $host="localhost";
    $dbUsername="root";
    $dbPassword="";
    $dbName="jezi";
    $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);  
    $department=$_POST['department'];
    $password=$_POST['password'];
    $query ="SELECT name from department where passw='$password' and name='$department'";
     $results=mysqli_query($con,$query);
     $num=mysqli_num_rows($results);
         if ($num){
             header('location:warehouse.php');
         }
         else{
            echo '<h1 style="color:red">Access denied wrong password</h1>'; 
         }
   }   
?>
<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Login | Warehouse  </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>WAREHOUSE</h1>
<form name="" action="" method="POST">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM employee where id='$login_session'";
            $records = mysqli_query($con,$sql);
            while($row = mysqli_fetch_array($records))
            {
                echo "<input type=hidden name=department value='".$row ['department']."'>";
                    }?> 
<input type="password" name="password" required>
<input type="submit" value="LOGIN">
</form>
 </body>
</html>