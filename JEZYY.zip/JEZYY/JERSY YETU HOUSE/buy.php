<?php
 session_start();
   $host="localhost";
   $dbUsername="root";
   $dbPassword="";
   $dbName="jezi";
   $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);
   if($con)
   $username=$_POST['username'];
   $product=$_POST['product'];
   $quantity=$_POST['quantity'];
   $price=$_POST['price'];
   $status="Received";
   $produ="Non";

    $sql="INSERT INTO cust_transacts(transact_by,product,quantity,price,status) VALUES('$username','$product','$quantity','$price','$status')" ;
    $query=mysqli_query($con,$sql);    
	   if($query){
		   header('location:products.php');
	   }
	   else
		   echo 'Try again to register with different username. Registration not successfull';
          include('cart.php');
?>   