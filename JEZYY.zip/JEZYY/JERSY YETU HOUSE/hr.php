<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Human resource </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>EMPLOYEE LIST</h1>
<section>
<a href="hr.php">VIEW EMPLOYEES</a>
</section>
 <section>
<a href="addemployee.php">RECRUIT EMPLOYEE</a>
</section>
<section>
<a href="department.php">DEPARTMENTS</a>
</section>
<div class="all_members">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM employee ORDER BY department_id";     
            $records = mysqli_query($con,$sql);?>
            <table>
                <thead>
                <tr>
                <th>Department id</th>
                <th>Employee Id.</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Gender</th>
                <th>Department</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['department_id'].'</td>';
                echo '<td>'.$row['id'].'</td>';
                echo '<td>'.$row['name'].'</td>';
                echo '<td>'.$row['phone'].'</td>';
                echo '<td>'.$row['gender'].'</td>';
                echo '<td>'.$row['department'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>    
                    </table>                      
                </div>
</div>
</body>
</html>