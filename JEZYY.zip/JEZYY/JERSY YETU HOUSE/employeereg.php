<?php
   session_start();
   $host="localhost";
   $dbUsername="root";
   $dbPassword="";
   $dbName="jezi";
   $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);
   if($con)
   $name=$_POST['name'];
   $email=$_POST['email'];
   $gender=$_POST['gender'];
   $idno=$_POST['idno'];
   $phone=$_POST['phone'];    
   $department=$_POST['department'];
   $dob=$_POST['dob'];
   $dep_id=$_POST['department_id'];
  
    $sql="INSERT INTO employee(name,id_no,email,phone,dob,gender,department,department_id,password) VALUES('$name','$idno','$email','$phone','$dob','$gender','$department','$dep_id','$email')" ;     $query=mysqli_query($con,$sql);
	   if($query){
		   header('location:addemployee.php');
	   }
	   else
		   echo 'Try again to register with different id number. Registration not successfull';
           include('addemployee.php');
?>