<?php
   session_start();
   $host="localhost";
   $dbUsername="root";
   $dbPassword="";
   $dbName="jezi";
   $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);
   if($con)
   $name=$_POST['name'];
   $code=$_POST['code'];
   $price=$_POST['price'];
  

    $sql="INSERT INTO products(name,code,price) VALUES('$name','$code','$price')" ;     $query=mysqli_query($con,$sql);
	   if($query){
		   header('location:addproducts.php');
	   }
	   else
		   echo 'Product registration not successfull';
           include('addproducts.php');
?>