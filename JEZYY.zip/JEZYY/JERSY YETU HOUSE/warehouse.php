<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Inventory </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>INVENTORY</h1>
<section>
 <a href="warehouse.php">INVENTORY</a> </section>
<section>
<a href="addproducts.php">ADD NEW PRODUCT</a>
</section><section>
<a href="">REPORTS</a> 
</section>
<div class="all_members">
<h2>Product code</h2>
<?php 
$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="jezi";

$conn=new mysqli($host, $dbUsername, $dbPassword, $dbName);

if($conn -> connect_error){
    die("connection failed:".$conn->connect_error);
}
$result = $conn->query("SELECT * from products");
echo "<select name='id'>";

while ($row = $result->fetch_assoc()){
    unset($cid,$fname,$emai,$sex,$dob);
    $cid = $row['code'];
    $fname = $row['name'];
    $email = $row['id'];
   
    echo '<option value="'.$cid.'">'.$cid.'</option>';
    
}
echo "</select>";
?>
</br></br>
<h2>Quantity</h2>
<input name="quantity" type="number" placeholder="Enter quantity"></br></br>
<h2>Date</h2>
<input name="date" type="date" required"></br></br>
<input type="submit" value="Submit"></form>
</div>
</body>
</html>