<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Welcome | Jersey Yetu House </title>

</head>
<body>
    <header>
    <a href="login.php">LOG IN</a> 
    <a href="products.php">PRODUCTS</a>
    <a href="index.php">HOME</a>
</header>
    <hr>
<h1>JERSEY YETU HOUSE</h1>
<h2>Welcome to the home of football jerseys where quality and variety is assured</h2>
<div class="images">
<div class="picSlides fade">
  <img src="img/bayern.jpg" style="width:60% ; height:400px" >
  <div class="text">BUNDESLIGA</div>
</div>
<div class="picSlides fade">
 
  <img src="img/epl.jpg" style="width:60% ; height:400px">
  <div class="text">INTERNATIONALS</div>
</div>
<div class="picSlides fade">
  <img src="img/ken.jpg" style="width:60% ; height:400px">
  <div class="text">LOCAL & NATIONAL TEAM</div>
</div>
</div>
<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>

<div class="image-box">
<h3 style="font-size: 50px"> Login to purchase your favourite jersey now </h3>
<div class="one">
<img src="img/kenb.jpg" style="width: 200px; height:200px">
<img src="img/arsenal.png" style="width: 200px; height:200px">
<img src="img/baca.jpg" style="width: 200px; height:200px">
<img src="img/united.png" style="width: 200px; height:200px">
</div>

</div>
<footer>
<p>JERSEY YETU HOUSE. Copyright 2020-2021</p>
  <a href= "#" >facebook</a>
  <a href= "#" >twitter</a>
  <a href= "#" >instagram</a>
  <a href= "#" >whatsapp +254775964029 </a>

</footer>
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("picSlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 4000); 
}
</script>
</body>
</html>