<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title> Transactions | Jersey Yetu House </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>TRANSACTIONS </h1>
<section>
<a href="transactions.php">TRANSACTIONS</a>
</section> 
<section>
<a href="customers.php">CUSTOMERS</a>
</section>
<section>
<a href="addemployee.php">ADD EMPLOYEE</a>
</section> <section>
<a href="addproducts.php">ADD PRODUCTS</a>
</section>
<div class="all_members">
<?php
            $con = mysqli_connect('localhost','root','');
            mysqli_select_db($con,'jezi');
            $sql = "SELECT * FROM cust_transacts order by date desc";     
            $records = mysqli_query($con,$sql);?>
            <table>
              
                <thead>
                <tr>
                <th>Username</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Time</th>
               </tr>
               </thead>
            <?php
            while($row = mysqli_fetch_array($records))
            {
                echo "<tbody>";
                echo "<tr>";
                echo '<td>'.$row['transact_by'].'</td>';
                echo '<td>'.$row['product'].'</td>';
                echo '<td>'.$row['quantity'].'</td>';
                echo '<td>'.$row['price'].'</td>';
                echo '<td>'.$row['date'].'</td>';

                echo "</tr>";
                echo "</tbody>";
                    }?>    
                    </table>                      
                </div>
               
                </body>
                </html>