<?php
   session_start();
   $host="localhost";
   $dbUsername="root";
   $dbPassword="";
   $dbName="jezi";
   $con=new mysqli($host, $dbUsername, $dbPassword, $dbName);
   if($con)
   $username=$_POST['username'];
   $name=$_POST['name'];
   $email=$_POST['email'];
   $gender=$_POST['gender'];
   $address=$_POST['address'];
   $phone=$_POST['phone'];    
   $password=$_POST['pass'];
   $conf=$_POST['passwordconf'];
   if($password==$conf){  
    $sql="INSERT INTO customers(username,name,email,gender,address,phone_number,Passw) VALUES('$username','$name','$email','$gender','$address','$phone','$password')" ;     $query=mysqli_query($con,$sql);
	   if($query){
		   $_SESSION['message']='You are now registered Log in';
		   header('location:login.php');
	   }
	   else
         echo '<h1 style="color:brown">Try again to register with different username or email. Registration not successfull</h1>';
           include('newuser.php');
   }else
      echo '<h1 style="color:brown">Password and password confirm dont match try again</h1>';
      include('newuser.php');
?>