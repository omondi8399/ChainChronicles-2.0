<?php
include('sessionstaff.php');
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<title>Home | Warehouse </title></head>
<body>
    <header>
    <a href="logout.php">LOG OUT</a>
    <a>User:<?php echo $login_session; ?> |</a>
</header>
    <hr>
<h1>MARKETING</h1>
<a href="">Members</a> |
<a href="">Strategy</a> |
<a href="">Reports</a> 
</body>
</html>