<?php
  include("db.php");
   session_start(); 
   if($_SERVER["REQUEST_METHOD"] == "POST") {   
      $userid = mysqli_real_escape_string($db,$_POST['userid']);
      $password = mysqli_real_escape_string($db,$_POST['password']);
      $sql = "SELECT id FROM employee WHERE id = '$userid' and password = '$password'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $count = mysqli_num_rows($result);
      if($count == 1) {
         session_start();
         $_SESSION['login_user'] = $userid;
         header("location: admin.php");
      }else {
         echo '<h1 style="color:red">Your Login id or Password is invalid please try again</h1>';
      }
   }
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css"></head>
<title>Login | Jersey Yetu House </title>
<body>
    <header>
    <a href="index.php">HOME</a>
</header>
    <hr>
<h1>ADMINISTRATORS LOGIN</h1>
<div class="login-box">
<form name="" action="" METHOD="POST">
    <h3>Employee Id</h3>
    <input type="text" name="userid" required>
    <h3>Password</h3>
    <input type="password" name="password" required>
    </br></br>
    <input type="submit" value="Login">
</br></br> 
    <a href="passwordrese.php">Password Reset</a>
</form>
<footer>
<p>JERSEY YETU HOUSE</p>
<p>Copyright 2020-2021</p>
</footer>
</body>
</html>