-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2021 at 10:06 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jezi`
--

-- --------------------------------------------------------

--
-- Table structure for table `cust_transacts`
--

CREATE TABLE `cust_transacts` (
  `t_id` int(20) NOT NULL,
  `transact_by` varchar(30) NOT NULL,
  `product` varchar(3000) NOT NULL,
  `quantity` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cust_transacts`
--

INSERT INTO `cust_transacts` (`t_id`, `transact_by`, `product`, `quantity`, `price`, `date`, `status`) VALUES
(1, 'veira', 'Kenya home', 3, 3900, '2021-07-29 07:51:40', 'Received'),
(2, 'veira', 'Kenya home', 6, 8100, '2021-07-29 08:15:24', 'Received'),
(3, 'veira', 'Kenya home', 2, 2700, '2021-07-29 08:18:01', 'Received'),
(4, 'veira', 'Arsenal Away', 5, 7500, '2021-07-29 08:52:35', 'Received'),
(5, 'veira', 'Arsenal Away', 5, 7500, '2021-07-29 09:19:34', 'Received'),
(6, 'veira', 'Arsenal Away', 5, 7500, '2021-07-29 09:19:34', 'Received'),
(7, 'veira', 'Arsenal Away', 4, 6000, '2021-07-29 09:36:36', 'Received'),
(8, 'veira', 'Kenya home', 8, 8600, '2021-08-04 14:52:05', 'Received'),
(13, 'veira', 'Kenya home', 3, 4500, '2021-08-05 15:53:23', 'Received'),
(14, 'veira', 'Kenya home', 8, 12300, '2021-08-05 16:02:33', 'Received'),
(15, 'veira', 'Kenya home', 8, 12300, '2021-08-05 16:19:52', 'Received'),
(16, 'veira', 'Man united Medium * 2\r\nArsenal home Small * 5\r\nGor Mahia green * 1\r\n', 8, 15300, '2021-08-05 16:35:40', 'received'),
(17, 'veira', 'Liverpool', 3, 4200, '2021-08-08 13:06:25', 'Received'),
(18, 'Daisy', 'Arsenal Away', 5, 7500, '2021-08-08 13:39:31', 'Received'),
(19, 'Daisy', 'Zambia home', 3, 4200, '2021-08-08 13:51:28', 'Received'),
(20, '', 'Man United', 5, 6200, '2021-08-08 15:33:14', 'Received');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cust_transacts`
--
ALTER TABLE `cust_transacts`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cust_transacts`
--
ALTER TABLE `cust_transacts`
  MODIFY `t_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
